package bankingLombok.model;



public class SavingAccount extends Account{
    public SavingAccount(String accountName){
        super(accountName);
    }
}